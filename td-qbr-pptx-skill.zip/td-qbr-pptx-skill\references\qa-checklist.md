# QBR PPTX QA Checklist

Run these checks before delivery.

## Required Commands

From `scripts/qbr-pptx-service`:

```powershell
npm install
npm test
```

If generating through HTTP:

```powershell
npm start
```

Then check:

```text
GET http://localhost:3010/health
POST http://localhost:3010/generate
```

## Functional QA

- PPTX is generated without errors.
- Output is editable `.pptx`, not screenshots.
- `debug: true` creates a deck spec JSON when needed.
- Signed download URL works before expiry.
- `outputFileName` is sanitized and preserved where possible.
- Unsupported path traversal filenames are not used.

## Content QA

- Client, reporting period, comparison period, language, and currency are correct.
- KPI values match the payload.
- Variance direction is not contradicted by headings.
- Currency symbols and non-English characters are not mojibake.
- Publisher/program names are preserved.
- AI-supplied headings do not override validated metric logic when they contradict the data.

## Visual QA

- Blue slides use the blue TD QBR background.
- Content slides use the light TD QBR background.
- Watermarks remain subtle and do not obscure text.
- KPI cards use the compact service style.
- Tables are aligned, readable, and use variance colors correctly.
- No generic greige-heavy card deck, clip-art, chevron filler, or old template style appears.

## Final Delivery

Return:

- PPTX file path or URL.
- Deck spec path or URL if `debug: true`.
- Commands run.
- Any unresolved visual or data limitations.
