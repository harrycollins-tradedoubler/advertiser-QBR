# QBR PPTX Service Contract

Use `scripts/qbr-pptx-service` as the source of truth for generation.

## Runtime

From the service folder:

```powershell
npm install
npm test
npm start
```

Default local URL:

```text
http://localhost:3010
```

Default local API key:

```text
td-qbr-pptx-local-2026-secret
```

Override with:

```text
QBR_PPTX_API_KEY=your-secret
PORT=3010
PUBLIC_BASE_URL=https://your-host
DOWNLOAD_URL_TTL_SECONDS=3600
QBR_AUTO_TRANSLATE=0
```

## Endpoints

- `GET /health`
- `POST /generate`
- `GET /files/:fileName`

`POST /generate` requires:

```text
Content-Type: application/json
Accept: application/json
x-api-key: td-qbr-pptx-local-2026-secret
```

Successful responses include `pptx_url`, optional `deck_spec_url` when `debug: true`, `file_name`, and expiry metadata.

## Core Payload Fields

Use the bundled `sample-payload.json` as the working example.

Required or strongly preferred:

- `client`
- `deckTitle`
- `themeName`: usually `TD`
- `reportingPeriod`: ISO-like range text, for example `2025-12-01 to 2026-03-25`
- `comparisonPeriod`
- `currencyCode`
- `languageCode`
- `programOutput`
- `programYoYTable`
- `publisherAnalysis`
- `publisherTables`

Useful controls:

- `fullContent`: default true
- `includeAppendix`: true to include appendix/detail slides
- `outputFileName`: preferred PPTX filename
- `debug`: true to save the generated deck spec JSON
- `targetSlides`: limits generated slides
- `slideBlueprint`: explicit slide sequence
- `slideTableBindings`: maps slide keys to table keys
- `themeOverrides`: controlled overrides only when intentionally changing the TD theme

## Table Inputs

The service normalizes multiple table names into canonical keys. Prefer these names:

- `segmentSummary`
- `top10Increase`
- `top10Decrease`
- `top10ByOV`
- `publisherPerformanceSummary`
- `kpiSummary`
- `kpiHighlights`
- `kpiHighlightNarrative`
- `kpiVarianceColorHints`
- `programLevelBreakdown`
- `moversCommission`
- `moversSales`
- `moversClicks`
- `moversAov`
- `brandNewPrograms`
- `brandNewPublishers`
- `newEmergingPublishers`
- `stoppedActivity`
- `salesGrowthSignals`
- `riskDependencies`

Rows can be arrays of objects. The service infers columns, numeric alignment, variance color, and some semantic headings.

## Default Slide Sequence

The normal QBR flow is:

1. Cover
2. Reporting period / executive summary
3. Publisher activity or publisher performance overview
4. KPI summary
5. Program-level breakdown
6. KPI highlights and implications
7. Movers and shakers
8. Brand-new or emerging publishers/programs
9. Sales growth signals
10. Risks and dependencies
11. Appendix when requested
12. Thank you

Do not replace this with generic `cover / bullets / kpis / comparison / closing` archetypes unless the user explicitly asks for a non-QBR deck.

## Direct Module Use

Agents may call the module instead of starting HTTP:

```js
const { generatePresentation, saveOutput } = require("./lib/generator");
const result = await generatePresentation(payload);
await saveOutput(result, "./outputs");
```

Use this when a local script is simpler than running the service.
