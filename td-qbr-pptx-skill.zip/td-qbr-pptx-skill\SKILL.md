---
name: td-qbr-pptx
description: Generate editable Tradedoubler QBR PowerPoint decks using the bundled Node.js qbr-pptx-service, TD QBR backgrounds, KPI/table layouts, localization behavior, and established QBR slide system. Use when the user asks to create, update, review, or automate a Tradedoubler QBR PPTX deck from QBR data, publisher tables, KPI summaries, or n8n payloads.
---

# TD QBR PPTX

Use this skill to create editable Tradedoubler QBR PowerPoint decks with the approved Node.js generation service and established TD QBR visual system.

## Non-negotiables

- Use `scripts/qbr-pptx-service` as the generation engine.
- Do not recreate the deck with `python-pptx`, generic presentation tooling, screenshots, or a new ad hoc renderer.
- Keep the output editable `.pptx`.
- Preserve the QBR design chrome: blue and light TD backgrounds, subtle watermark geometry, compact KPI cards, structured tables, and clean executive-report spacing.
- Preserve the service behavior for currency, locale labels, table normalization, variance coloring, signed file links, and mojibake repair.
- Do not invent a new TD brand system, palette, font stack, logo treatment, or slide taxonomy.

## Quick Workflow

1. Read the request and identify whether the user wants a generated deck, a service change, a payload fix, or a design review.
2. For deck generation, load `references/service-contract.md` and use the Node service or `generatePresentation` module.
3. For visual/design decisions, load `references/design-system.md`.
4. Build or validate a payload with QBR fields, KPI rows, publisher/program tables, language, currency, and output filename.
5. Run from `scripts/qbr-pptx-service`:

```powershell
npm install
npm test
npm start
```

6. POST the payload to `http://localhost:3010/generate` with `x-api-key`, or call `generatePresentation(payload)` directly from Node.
7. Run the QA checklist in `references/qa-checklist.md` before delivering the `.pptx`.

## Local Requirements

Colleagues do not need PowerPoint to generate the file. They need:

- Codex or another environment that can use this skill folder.
- Node.js and npm to run the bundled service.
- Internet access only if `QBR_AUTO_TRANSLATE` is enabled for automatic translation.

PowerPoint, Teams, or OneDrive are optional for opening, editing, and sharing the final deck. Python is not required.

## Resources

- `scripts/qbr-pptx-service/` is the bundled Node.js PPTX generator.
- `references/service-contract.md` documents endpoints, payload shape, table keys, and runtime options.
- `references/design-system.md` documents the visual system, colors, typography, watermarks, and slide patterns.
- `references/qa-checklist.md` documents verification steps.
