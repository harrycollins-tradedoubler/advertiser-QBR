# TD QBR Design System

This is the practical design contract implemented by the Node.js service.

## Theme Tokens

Default font stack:

- Heading: `Aptos`
- Body: `Aptos`
- Mono: `Aptos`

Default colors:

- Ink: `#2F333B`
- Paper: `#F3F4F6`
- Canvas: `#E8EDF9`
- Accent blue: `#2F6FF2`
- Negative / risk: `#EB5757`
- Success: `#57A66C`
- Warning: `#F2C94C`
- Highlight: `#AFC4F5`
- Muted text: `#5B6372`
- Border: `#D8DCE5`

Do not substitute the older colleague-template palette (`#2B73FF`, greige panels, broad secondary colors) unless the service theme is deliberately changed.

## Backgrounds And Watermarks

The service uses two full-slide background images:

- `assets/qbr-bg-blue.png` for cover and closing/blue slides.
- `assets/qbr-bg-light.png` for normal content slides.

If those images are missing, the service falls back to generated watermark geometry:

- Faint wireframe polygon cluster in the upper/right or lower/right visual field.
- Small TD dot/triangle pattern near the lower-left.
- Low contrast only; the watermark must never compete with tables or text.

Do not use standalone logo PNGs as the main design system. The current QBR deck expresses TD through the background chrome, blue field, `td` cover mark, typography, and structured reporting layouts.

## Layout Language

Use a 16:9 deck: `13.333 x 7.5`.

Common geometry:

- Main content begins around `x=0.7`.
- Titles sit near `y=0.58`.
- Title size is usually `28`.
- Body/table copy is compact, usually `9-12`.
- Slides should read as executive reporting, not as a sales brochure.

Avoid:

- Large generic greige panels.
- Repeated `title + 3 cards` layouts.
- Decorative chevrons/parallelograms that are not part of the service chrome.
- Rainbow accents or excessive secondary colors.
- Generic PowerPoint placeholders.

## Cover And Closing

Blue slides use `qbr-bg-blue.png`.

Cover behavior:

- Large title on the left/top.
- The phrase `Business Review` may be highlighted in ink against the blue field.
- Summary sits below in white.
- Compact `QBR Report` pill and period analysis tag.
- Large editable `td` mark and small `tradedoubler` wordmark near the bottom-left.

Closing behavior:

- Blue background.
- Simple title.
- One translucent question band.
- No busy contact card unless the user supplies specific contact details.

## KPI Treatment

KPI slides use compact editable cards:

- Three cards on the first row, two cards offset below for a five-card diamond layout.
- Thin accent bar across each card top.
- Centered circular icon badge above the card.
- KPI label and summary stay short.
- Delta text is colored by trend: success green for positive, red for negative, muted for neutral.

Do not replace the KPI system with oversized empty cards or generic metric tiles.

## Tables

Tables are central to the QBR deck.

Rules:

- Header row: compact, bold, light fill.
- Alternating body rows: subtle greys.
- Numeric and KPI columns align right.
- Delta / variance columns use semantic color.
- Section rows can be slightly darker.
- Tables should remain readable at live-presentation size.

When a table is too dense, reduce columns, split the table, or use appendix slides. Do not shrink text until it becomes unreadable.

## Narrative Tone

Use direct executive language:

- What changed.
- Why it matters.
- Which publisher/program/metric drove it.
- What action follows.

Avoid AI-sounding language:

- "Unlocking synergies"
- "Leverage strategic opportunities"
- "Robust ecosystem"
- "Dynamic performance landscape"
- Long generic paragraphs that do not cite a metric or named driver.
